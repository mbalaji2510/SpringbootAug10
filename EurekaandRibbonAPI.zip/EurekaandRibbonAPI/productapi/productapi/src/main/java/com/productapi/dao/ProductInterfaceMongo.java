package com.productapi.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import com.productapi.entity.Product;
@Repository
public interface ProductInterfaceMongo extends MongoRepository<Product, String> {

	
	
}

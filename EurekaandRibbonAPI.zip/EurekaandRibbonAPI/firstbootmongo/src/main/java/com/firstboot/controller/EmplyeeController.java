package com.firstboot.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.firstboot.dao.EmployeeDAOInterface;
import com.firstboot.dao.EmployeeDAOInterfaceMongo;
import com.firstboot.entity.Employee;
import com.firstboot.entity.EmployeeMongo;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@RequestMapping("allEmployeejpa")
public class EmplyeeController {
	
	@Autowired
	private EmployeeDAOInterface empdao;
	
	@RequestMapping("allEmployee")
	public List<Employee> displayAllEmployee(){
		List<Employee> el=new ArrayList<Employee>();
		Employee e1=new Employee();
		e1.setName("Rajesh");
		e1.setPassword("abcd");
		e1.setEmail("abc@yahoo.com");
		e1.setAddress("Bangalore");
		
		el.add(e1);
		return el;
	}
	
	@RequestMapping("allEmployeejdbc")
	@HystrixCommand(fallbackMethod = "userDefinedMethod")
	public List<Employee> displayAllEmployeejdbc(){
		List<Employee> el=empdao.getdaoall();
		if(el.size()>0) {
			throw new ArithmeticException();
		}
		return el;
		
	}
	
	public List<Employee> userDefinedMethod(){
		List<Employee> el=new ArrayList<Employee>();
		Employee e1=new Employee();
		e1.setName("default_name");
		e1.setPassword("default");
		e1.setEmail("mailto:default@yahoo.com");
		e1.setAddress("Chennai");
		el.add(e1);
		return el;
	}
	@RequestMapping("/emp/")
	public List<Employee> displayAllEmployeejpa(){
		List<Employee> el=empdao.getdaoalljpa();
		
		return el;
	}

	@RequestMapping(value="/emp/", method=RequestMethod.POST )
	 public void createEmpData(@RequestBody Employee employee){
		empdao.createEmpData(employee);
		
	}
	
	@RequestMapping(value="/emp/{name}", method=RequestMethod.PUT )
	public ResponseEntity<?> updateEmpData(@PathVariable("name") String name, @RequestBody Employee employee){
		
		Employee currentemp = empdao.findEmpData(name);
		
		if (currentemp == null) {
						
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		}
		
		currentemp.setPassword(employee.getPassword());
		currentemp.setEmail(employee.getEmail());
		currentemp.setAddress(employee.getAddress());
		empdao.updateEmpData(currentemp);
		return new ResponseEntity<Employee>(currentemp, HttpStatus.OK);
	}
	
	@RequestMapping(value="/emp/{name}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteEmpData(@PathVariable("name") String name){
		Employee emp = empdao.findEmpData(name);
		
		if (emp == null) {
						
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		}
		empdao.removeEmpData(emp);
		return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		
	}
	@Autowired
	private EmployeeDAOInterfaceMongo empmongo;
	
	@RequestMapping("allEmployeemongo")
	public List<EmployeeMongo> displayAllEmployeemongo(){
		List<EmployeeMongo> el=empmongo.findAll();
		
		return el;
	}
}

package com.firstboot.dao;

import java.util.List;

import com.firstboot.entity.Employee;

public interface EmployeeDAOInterface {

	List<Employee> getdaoall();
	
	List<Employee> getdaoalljpa();
	
	void createEmpData(Employee emp);
	void updateEmpData(Employee emp);
	
	void removeEmpData(Employee emp);
	
	Employee findEmpData(String name);
	
}

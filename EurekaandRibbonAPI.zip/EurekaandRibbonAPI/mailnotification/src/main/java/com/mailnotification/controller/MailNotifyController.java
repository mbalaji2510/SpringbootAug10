package com.mailnotification.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class MailNotifyController {
	
	@RequestMapping("allMailNotification")
	@HystrixCommand(fallbackMethod = "userDefinedMethod")
	public MessageData dummyMessage(){
		MessageData message = new MessageData();
		message.setHost("xxx");
		message.setMessageType("HTML");
		message.setMessge("Email notification message");
		return message;
		
	}
		
	
	public MessageData userDefinedMethod(){
		MessageData message = new MessageData();
		message.setHost("Default");
		message.setMessageType("Default");
		message.setMessge("Default");
		return message;
	}

}

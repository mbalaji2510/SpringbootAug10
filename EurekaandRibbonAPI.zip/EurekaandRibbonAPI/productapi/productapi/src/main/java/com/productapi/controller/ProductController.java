package com.productapi.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.productapi.dao.ProductInterfaceMongo;
import com.productapi.entity.Product;


@RestController
public class ProductController {
	
	@Autowired
	private ProductInterfaceMongo productMongo;
	
	@RequestMapping("allproducts")
	@HystrixCommand(fallbackMethod = "userDefinedMethod")
	public List<Product> displayProduct(){
		List<Product> product=productMongo.findAll();
		if(product.size()>0) {
			throw new ArithmeticException();
		}
		return product;
	}
	
	public List<Product> userDefinedMethod(){
		System.out.println("Falut message");
		List<Product> p1=new ArrayList<Product>();
		Product p=new Product();
		p.setPrice("default");
		p.setProductId("defalut");
		p.setProductName("default");
		p1.add(p);
		return p1;
	}

}
